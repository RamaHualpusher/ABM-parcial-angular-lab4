export interface Articulo {
  id?: number;
  codigo: string;
  denominacion: string;
  precio: number;
  idrubro: number;
  nuevo?: string;
};
