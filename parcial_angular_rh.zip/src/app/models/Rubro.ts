export interface Rubro {
  id: number;
  denominacion: string;
}
